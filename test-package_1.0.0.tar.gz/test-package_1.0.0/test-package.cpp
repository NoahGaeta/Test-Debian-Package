#include <iostream>

int main() {
	std::cout << "Mochi and Java are cool cats" << std::endl;
	return 0;
}
